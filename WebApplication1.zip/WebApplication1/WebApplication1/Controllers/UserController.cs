﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class UserController : ApiController
    {
        private CapstoneEntities db = new CapstoneEntities();
        [HttpPost]
        public JObject GetUserLogin([FromBody] JObject loginJson)
        {
            JObject retJson = new JObject();
            string strAccountNumber = loginJson["username"].ToString();
            string strPassword = loginJson["password"].ToString();
            int userLogin = db.UserLogins.Where(n => n.AccountNumber.Equals(strAccountNumber) && n.Password.Equals(strPassword)).Select(n=>n.Id).FirstOrDefault();
            if (userLogin == null)
            {
                retJson.Add(new JProperty("authentication", "unsuccessful"));
            }
            else
            {
                retJson.Add(new JProperty("authentication", "successful"));
                retJson.Add(new JProperty("Id", userLogin));
            }

            return retJson;
        }

        [HttpGet]
        [Route("api/GetUserDetails")]
        public JObject GetUserLogin(int id)
        {
            JObject retJson = new JObject();
            var userLogin = db.UserAccounts.Where(n => n.AccountId.Equals(id)).FirstOrDefault();
            var finalAmt = db.UserTransactions.Where(n => n.AccountId.Equals(id)).OrderByDescending(n => n.Id).Take(1).FirstOrDefault();
            if (userLogin != null)
            {
                retJson.Add(new JProperty("AccountNumber", userLogin.AccountNumber));
                retJson.Add(new JProperty("First_Name", userLogin.First_Name));
                retJson.Add(new JProperty("Middle_Name", userLogin.Middle_Name));
                retJson.Add(new JProperty("Last_Name", userLogin.Last_Name));
                if (finalAmt != null)
                    retJson.Add(new JProperty("Closing_Balance", finalAmt.Closing_Balance));
                else
                    retJson.Add(new JProperty("Closing_Balance", 0.00));
            }
            return retJson;
        }

        [HttpPost]
        [Route("api/Transact")]
        public JObject SubTransact([FromBody] JObject loginJson)
        {
            JObject retJson = new JObject();
            
            UserTransaction userTransaction = new UserTransaction();
            userTransaction.AccountId = Convert.ToInt32(loginJson["AccountId"]);
            var finalAmt1 = db.UserTransactions.Where(n => n.AccountId.Equals(userTransaction.AccountId)).OrderByDescending(n => n.Id).Take(1).FirstOrDefault();
            userTransaction.Narration = loginJson["Narration"].ToString();
            userTransaction.Withdrawal = Convert.ToDecimal(loginJson["Withdrawal"]);
            userTransaction.Deposit = Convert.ToDecimal(loginJson["Deposit"]);
            Random random = new Random(DateTime.Now.Millisecond);

            if (!loginJson["Deposit"].ToString().Equals("0"))
            {
                userTransaction.Closing_Balance = finalAmt1.Closing_Balance + Convert.ToDecimal(loginJson["Amount"]);
                userTransaction.TransactID = "DO" + random.Next().ToString();
            }
            else
            {
                userTransaction.Closing_Balance = finalAmt1.Closing_Balance - Convert.ToDecimal(loginJson["Amount"]);
                userTransaction.TransactID = "WD" + random.Next().ToString();
            }
            userTransaction.CreatedDate = System.DateTime.Now;
            userTransaction.ModifiedDate = System.DateTime.Now;
            userTransaction.IsActive = true;
            userTransaction.CreatedBy = HttpContext.Current.Request.LogonUserIdentity.Name;
            userTransaction.ModifiedBy = HttpContext.Current.Request.LogonUserIdentity.Name;

            

            db.UserTransactions.Add(userTransaction);
            db.SaveChanges();

            var finalAmt = db.UserTransactions.Where(n => n.AccountId.Equals(userTransaction.AccountId)).OrderByDescending(n => n.Id).Take(1).FirstOrDefault();
            if (finalAmt != null)
                retJson.Add(new JProperty("Closing_Balance", finalAmt.Closing_Balance));
            else
                retJson.Add(new JProperty("Closing_Balance", 0.00));
            return retJson;
        }

        [HttpPost]
        [Route("api/GetAccountInfoDetails")]
        public List<JObject> GetAccountInfo([FromBody] JObject loginJson)
        {
            List<JObject> retJson = new List<JObject>();
            using (CapstoneEntities context = new CapstoneEntities())
            {
                IEnumerable<GetAccountTransInfo_Result> getAccountTransInfo_Results = context.GetAccountTransInfo(Convert.ToInt32(loginJson["AccountId"]), loginJson["Type"].ToString());

                foreach (var v in getAccountTransInfo_Results)
                {
                    JObject obj = new JObject();
                    obj.Add("Narration", v.Narration);
                    obj.Add("Withdrawal", v.Withdrawal);
                    obj.Add("Deposit", v.Deposit);
                    obj.Add("Closing_Balance", v.Closing_Balance);
                    obj.Add("CreatedDate", v.CreatedDate);

                    retJson.Add(obj);
                }
            }
            return retJson;
        }
    }
}
